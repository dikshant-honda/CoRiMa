# -*- coding: utf-8 -*-
#
#
# Copyright (C)
# Honda Research Institute Europe GmbH
# Carl-Legien-Str. 30
# 63073 Offenbach/Main
# Germany
#
# UNPUBLISHED PROPRIETARY MATERIAL.
# ALL RIGHTS RESERVED.
#
# pylint: disable=import-outside-toplevel,too-many-locals
from __future__ import annotations

from math import sqrt
from typing import TYPE_CHECKING

from risk_model import Probability, UncertainTrajectory

from .artist import create_ellipse
from .import_guard import ensure_matplotlib_pyplot

if TYPE_CHECKING:
    from matplotlib.artist import Artist
    from matplotlib.patches import Ellipse


def _update_ellipse(ellipse: Ellipse, trajectory: UncertainTrajectory, index: int) -> None:
    position = trajectory.positions[index]
    sigma = trajectory.covariance_matrices[index]
    angle = trajectory.angles()[index]
    width = sqrt(sigma[0][0])
    height = sqrt(sigma[1][1])

    ellipse.set_angle(angle)
    ellipse.set_center(position)
    ellipse.set_width(width)
    ellipse.set_height(height)


def animate(trajectories: list[UncertainTrajectory]) -> None:

    ensure_matplotlib_pyplot()
    from matplotlib.animation import FuncAnimation
    from matplotlib.pyplot import figure, gca, show, title, xlabel, xlim, ylabel, ylim

    fig = figure()
    axes = gca()

    artists = []

    for trajectory in trajectories:
        if len(trajectory.positions) == 0:
            continue

        is_ego = trajectory.id == "ego"
        color = "green" if is_ego else "black"
        zorder = 1 if is_ego else 0

        ellipse = axes.add_artist(
            create_ellipse(
                (0, 0),
                (0, 0),
                0,
                color=color,
                alpha=1.0,
                zorder=zorder,
            )
        )
        _update_ellipse(ellipse, trajectory, 0)

        artists.append((trajectory, ellipse))

    title("Gaussian sizes")
    xlim([-20.0, 20.0])
    ylim([-20.0, 20.0])
    ylabel("y-position in m")
    xlabel("x-position in m")

    def _frame(frame_number: int) -> list[Artist]:
        changed_artists = []
        for trajectory, ellipse in artists:
            if frame_number >= len(trajectory.positions):
                continue
            _update_ellipse(ellipse, trajectory, frame_number)
            changed_artists.append(ellipse)
        return changed_artists

    _ = FuncAnimation(fig, _frame, frames=240, interval=200, cache_frame_data=False)

    show()
